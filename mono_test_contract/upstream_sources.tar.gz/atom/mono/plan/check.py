# SPDX-License-Identifier: MIT
# Copyright (C) 2026, Advanced Micro Devices, Inc. All rights reserved.
"""The hand-off contract of a traced kernel, checked at build time.

A mono kernel's CTAs are all co-resident and each walks the program's stages in
order, a stage's tasks spread over the grid. A poll then always makes progress if
the stage it waits on comes earlier in the program, or is its own stage and the
region an exchange (an all-reduce: a task pushes before it waits on its peers'
pushes). ``check`` holds a ``trace.Record`` to that and to the regions'
declarations: the stages that put each, the declared space (scope), and no
mailbox access on an unnamed address.

A kernel whose grid is split by role breaks the "each CTA walks every stage"
premise: its roles are branches on the CTA id, so two stages of one program can
run at once on disjoint CTAs and their source order orders nothing. A region
handed between two such roles is declared ``concurrent``, which is a claim about
the grid (the writer's and the poller's CTA sets do not meet) that the checker
cannot see and the model's layout must make good -- the progress argument is
then co-residency, not program order.
"""

from dataclasses import dataclass

from atom.mono.plan.trace import Record, Space


@dataclass(frozen=True)
class RegionDecl:
    name: str
    space: Space
    # the stage that puts it; several when the step's input picks which one puts a
    # cell (a token's last index tree level): every one runs before a poller
    writer: str | tuple[str, ...]
    exchange: bool = False  # polled by its writer stage too (an all-reduce)
    # handed between two roles of a split grid: the poller's CTAs and the
    # writer's do not meet, so program order does not order the two stages and
    # the poll may name a writer that comes later
    concurrent: bool = False

    @property
    def writers(self) -> tuple[str, ...]:
        return (self.writer,) if isinstance(self.writer, str) else self.writer


class ContractError(Exception):
    """A traced kernel breaks its hand-off contract."""


def check(record: Record, decls: list[RegionDecl]) -> None:
    """Raise ``ContractError`` listing every breach of ``record`` against
    ``decls``."""
    by_name = {d.name: d for d in decls}
    first = {}
    for i, stage in enumerate(record.stages):
        first.setdefault(stage, i)
    problems = [
        f"{kind} on an unnamed address in {stage}" for stage, kind in record.unnamed
    ]
    used = set()
    polled_before_put: set[tuple[str, str]] = set()
    put_seen: set[tuple[str, str]] = set()
    for a in record.accesses:
        d = by_name.get(a.region)
        if d is None:
            problems.append(f"{a.kind} of undeclared region {a.region} in {a.stage}")
            continue
        used.add(a.region)
        if a.space is not d.space:
            problems.append(
                f"{a.kind} of {a.region} in {a.stage} as {a.space.value}, declared {d.space.value}"
            )
        if a.kind == "put":
            put_seen.add((a.stage, a.region))
            if a.stage not in d.writers:
                problems.append(
                    f"{a.region} put by {a.stage}, its writer is {d.writer}"
                )
            continue
        if a.stage in d.writers:
            if not d.exchange:
                problems.append(
                    f"{a.region} polled by its own writer {a.stage} (not an exchange)"
                )
            elif (a.stage, a.region) not in put_seen:
                polled_before_put.add((a.stage, a.region))
        else:
            for w in d.writers:
                if w not in first:
                    problems.append(
                        f"{a.region} polled by {a.stage}, its writer {w} never runs"
                    )
                elif first[w] > first[a.stage] and not d.concurrent:
                    problems.append(
                        f"{a.region} polled by {a.stage}, which runs before its writer {w}"
                    )
    for stage, region in sorted(polled_before_put):
        problems.append(f"exchange {region} polled in {stage} before any put of it")
    for name in sorted(set(by_name) - used):
        problems.append(f"declared region {name} is never accessed")
    if problems:
        raise ContractError("\n".join(problems))
